Exported Timestamp (UTC+0000): 2024-11-01 04:07:15
Exported through Raw-data-api (https://github.com/hotosm/raw-data-api) using OpenStreetMap data.
 Exports are made available under the Open Database License: http://opendatacommons.org/licenses/odbl/1.0/. Any rights in individual contents of the database are licensed under the Database Contents License: http://opendatacommons.org/licenses/dbcl/1.0/. 
 Learn more about OpenStreetMap and its data usage policy : https://www.openstreetmap.org/about 
